<?php 
$host="localhost";
$user='id12706313_kuisioner';
$pass='u\dela&FIFAH09';
$database='id12706313_covid19';

$konek = mysqli_connect($host, $user, $pass);

mysqli_select_db($konek, $database);

?>